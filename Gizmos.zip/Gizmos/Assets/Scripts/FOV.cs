using UnityEditor;
using UnityEngine;

public class FOV : MonoBehaviour
{
    [SerializeField, Range(0, 360)] private float _fovAngle = 60f;
    [SerializeField, Range(0, 100)] private float _distance = 20f;

    [SerializeField] private Color _color = Color.green;
    private void OnDrawGizmos()
    {
        Vector3 direction = Quaternion.AngleAxis(-_fovAngle * 0.5f, transform.up) * transform.forward;
        Handles.color = _color;
        Handles.DrawSolidArc(transform.position, transform.up, direction,_fovAngle, _distance);
    }
}
