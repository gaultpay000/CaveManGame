using System.Collections.Generic;
using System.Threading;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIHandler : MonoBehaviour
{
    [SerializeField] private InventoryHandler _inventory;
    private int _curIndex;
    [SerializeField] private TMP_Text _weaponDisplay;
    [SerializeField] private float _curHP;
    [SerializeField] private float _maxHP = 100;
    [SerializeField] private Slider _healthSlider;
    [SerializeField] private GameObject _arrowTrackers;
    [SerializeField] private bool _isUsingBow = false;
    public float getHP { get { return _curHP; } set { _curHP = value; } }

    public void Awake()
    {
        getHP = _maxHP;
        OnChangeHealth(0);
        _curIndex = 0;
        OnChangeWeapon(_inventory._weapons[_curIndex]);
    }

    public void OnChangeHealth(float Change)
    {
        _curHP -= Change;
        if (_curHP > _maxHP)
        {
            _curHP = _maxHP;
        }
        else if (_curHP < 0)
        { 
            _curHP = 0;
        }
        _healthSlider.value = _curHP/_maxHP;
    }
    public void OnChangeWeapon(GameObject curWeapon)
    {
        if (curWeapon.name == "Bow")
        {
            _isUsingBow = true;
        }
        else
        {
            _isUsingBow = false;
        }

        _arrowTrackers.SetActive(_isUsingBow);
        _weaponDisplay.text = $"Current Weapon: {curWeapon.name}";
    }

    public void WeaponCycle()
    {
        _curIndex++;
        if (_curIndex < _inventory._weapons.Length)
        {
            OnChangeWeapon(_inventory._weapons[_curIndex]);
        }
        else if (_curIndex >= _inventory._weapons.Length)
        {
            _curIndex = 0;
            OnChangeWeapon(_inventory._weapons[_curIndex]);
        }
    }
}
