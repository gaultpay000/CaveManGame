using UnityEngine;
using UnityEngine.Events;

public class ExplosiveLogic : MonoBehaviour
{
    [SerializeField] private float ExplosionRadius;
    public UnityEvent OnExplode;

    public void Exploded(Vector3 origin, float radius)
    {
        Collider[] colliders = Physics.OverlapSphere(origin, radius);
        foreach (Collider collider in colliders)
        { 
            IDamageable objectToDamage = collider.gameObject.GetComponent<IDamageable>();
            if(collider.gameObject.GetComponent<IDamageable>() != null)
            {
                objectToDamage.TakeDamage();
            }
        }
    }

    public void OnDrawGizmos()
    {
        Gizmos.color = Color.red;

        Gizmos.DrawWireSphere(transform.position, ExplosionRadius);
    }
}
